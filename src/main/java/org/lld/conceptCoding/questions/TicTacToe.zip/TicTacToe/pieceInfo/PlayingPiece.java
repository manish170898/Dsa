package org.lld.conceptCoding.questions.TicTacToe.pieceInfo;

public class PlayingPiece {
    PieceType pieceType;
    public PlayingPiece(PieceType pieceType) {
        this.pieceType = pieceType;
    }
}
