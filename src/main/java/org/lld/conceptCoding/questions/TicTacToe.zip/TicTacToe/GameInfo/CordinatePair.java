package org.lld.conceptCoding.questions.TicTacToe.GameInfo;

public class CordinatePair {
    Integer x;
    Integer y;
    public CordinatePair(Integer x, Integer y){
        this.x = x;
        this.y = y;
    }

}
