package org.lld.conceptCoding.questions.TicTacToe;

import org.lld.conceptCoding.questions.TicTacToe.GameInfo.Board;
import org.lld.conceptCoding.questions.TicTacToe.GameInfo.TicTacToe;
import org.lld.conceptCoding.questions.TicTacToe.pieceInfo.PieceO;
import org.lld.conceptCoding.questions.TicTacToe.pieceInfo.PieceX;
import org.lld.conceptCoding.questions.TicTacToe.pieceInfo.PlayingPiece;
import org.lld.conceptCoding.questions.TicTacToe.playerInfo.Player;

import java.util.Deque;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        PlayingPiece crossPiece = new PieceX();
        PlayingPiece circlePiece = new PieceO();
        Player player1 = new Player("Manish", crossPiece);
        Player player2 = new Player("Shivang", circlePiece);
        Deque<Player> players = new LinkedList<>();
        players.add(player1);
        players.add(player2);
        Board board = new Board(3);
        TicTacToe ticTacToe = new TicTacToe(players, board);
        System.out.println(ticTacToe.startGame());
    }
}
